'use client';

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export default function Hero3DCanvas() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    const width = container.clientWidth;
    const height = container.clientHeight;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 7;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // Group to hold all 3D objects
    const mainGroup = new THREE.Group();
    scene.add(mainGroup);

    // 1. Central Hero Torus Knot (Sculptural Tech Art)
    const geometry = new THREE.TorusKnotGeometry(1.2, 0.38, 128, 32, 2, 3);
    const material = new THREE.MeshPhysicalMaterial({
      color: 0x6366f1,
      emissive: 0x1e1b4b,
      roughness: 0.15,
      metalness: 0.85,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1,
      reflectivity: 0.9,
      wireframe: false,
    });
    const torusKnot = new THREE.Mesh(geometry, material);
    mainGroup.add(torusKnot);

    // 2. Surrounding Glowing Ring 1
    const ringGeo1 = new THREE.TorusGeometry(2.3, 0.04, 16, 100);
    const ringMat1 = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      metalness: 0.9,
      roughness: 0.1,
    });
    const ring1 = new THREE.Mesh(ringGeo1, ringMat1);
    ring1.rotation.x = Math.PI / 3;
    mainGroup.add(ring1);

    // 3. Surrounding Glowing Ring 2
    const ringGeo2 = new THREE.TorusGeometry(2.8, 0.03, 16, 100);
    const ringMat2 = new THREE.MeshStandardMaterial({
      color: 0xf43f5e,
      emissive: 0xe11d48,
      metalness: 0.8,
      roughness: 0.2,
    });
    const ring2 = new THREE.Mesh(ringGeo2, ringMat2);
    ring2.rotation.y = Math.PI / 4;
    mainGroup.add(ring2);

    // 4. Floating Tech Satellites / Spheres
    const satelliteGroup = new THREE.Group();
    const satGeo = new THREE.IcosahedronGeometry(0.28, 2);
    const satColors = [0x38bdf8, 0xa855f7, 0xf59e0b, 0x10b981];
    const satellites: THREE.Mesh[] = [];

    for (let i = 0; i < 4; i++) {
      const satMat = new THREE.MeshPhysicalMaterial({
        color: satColors[i],
        metalness: 0.6,
        roughness: 0.2,
        clearcoat: 0.8,
      });
      const sat = new THREE.Mesh(satGeo, satMat);
      const angle = (i / 4) * Math.PI * 2;
      sat.position.set(Math.cos(angle) * 3.2, Math.sin(angle) * 1.8, (Math.random() - 0.5) * 1.5);
      satelliteGroup.add(sat);
      satellites.push(sat);
    }
    mainGroup.add(satelliteGroup);

    // 5. Ambient Particle Star Dust
    const particleCount = 200;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 14;
      positions[i + 1] = (Math.random() - 0.5) * 10;
      positions[i + 2] = (Math.random() - 0.5) * 8;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x93c5fd,
      size: 0.045,
      transparent: true,
      opacity: 0.6,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const pointLight1 = new THREE.PointLight(0x60a5fa, 4, 20);
    pointLight1.position.set(5, 5, 5);
    scene.add(pointLight1);

    const pointLight2 = new THREE.PointLight(0xf43f5e, 3, 20);
    pointLight2.position.set(-5, -4, 3);
    scene.add(pointLight2);

    const pointLight3 = new THREE.PointLight(0x34d399, 2, 15);
    pointLight3.position.set(0, 4, -3);
    scene.add(pointLight3);

    // Mouse Parallax Interaction
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;

    const handleMouseMove = (event: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width - 0.5;
      const y = (event.clientY - rect.top) / rect.height - 0.5;
      targetX = x * 1.5;
      targetY = y * 1.2;
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Resize Observer
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animationFrameId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Smooth mouse interpolation
      mouseX += (targetX - mouseX) * 0.05;
      mouseY += (targetY - mouseY) * 0.05;

      // Rotate central hero mesh
      torusKnot.rotation.x = elapsedTime * 0.4 + mouseY * 0.8;
      torusKnot.rotation.y = elapsedTime * 0.5 + mouseX * 1.2;

      // Animate rings
      ring1.rotation.z = elapsedTime * 0.25;
      ring1.rotation.x = Math.PI / 3 + Math.sin(elapsedTime * 0.5) * 0.2;
      ring2.rotation.z = -elapsedTime * 0.3;

      // Animate satellite orbit
      satelliteGroup.rotation.y = elapsedTime * 0.35 + mouseX * 0.5;
      satelliteGroup.rotation.x = Math.sin(elapsedTime * 0.5) * 0.2 + mouseY * 0.5;

      satellites.forEach((sat, idx) => {
        sat.rotation.x += 0.02;
        sat.rotation.y += 0.03;
        sat.position.y += Math.sin(elapsedTime * 2 + idx) * 0.003;
      });

      // Subtle particle float
      particles.rotation.y = elapsedTime * 0.03;

      // Group tilt
      mainGroup.rotation.x = mouseY * 0.4;
      mainGroup.rotation.y = mouseX * 0.6;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
      geometry.dispose();
      material.dispose();
      ringGeo1.dispose();
      ringMat1.dispose();
      ringGeo2.dispose();
      ringMat2.dispose();
      particleGeo.dispose();
      particleMat.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      id="hero-3d-canvas-container"
      className="relative w-full h-[320px] md:h-[400px] flex items-center justify-center pointer-events-auto cursor-grab active:cursor-grabbing select-none"
    />
  );
}

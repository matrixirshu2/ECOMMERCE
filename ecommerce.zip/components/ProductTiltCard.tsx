'use client';

import React, { useRef, useState } from 'react';
import { Heart, Plus, Eye, Sparkles } from 'lucide-react';
import { money, Product } from '@/app/store';

interface ProductTiltCardProps {
  product: Product;
  onAddToCart: (p: Product) => void;
  onInspect3D: (p: Product) => void;
  isWishlisted: boolean;
  onToggleWishlist: (id: string) => void;
}

export default function ProductTiltCard({
  product,
  onAddToCart,
  onInspect3D,
  isWishlisted,
  onToggleWishlist,
}: ProductTiltCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glarePos, setGlarePos] = useState({ x: 50, y: 50, opacity: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rX = ((y - centerY) / centerY) * -12; // tilt angle
    const rY = ((x - centerX) / centerX) * 12;

    setRotateX(rX);
    setRotateY(rY);
    setGlarePos({
      x: (x / rect.width) * 100,
      y: (y / rect.height) * 100,
      opacity: 0.15,
    });
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setGlarePos((prev) => ({ ...prev, opacity: 0 }));
  };

  return (
    <div
      ref={cardRef}
      id={`product-card-${product.id}`}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        transform: `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(0)`,
        transition: 'transform 0.15s ease-out, box-shadow 0.2s ease',
      }}
      className="group relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm hover:shadow-2xl hover:border-indigo-300 dark:hover:border-indigo-600 flex flex-col justify-between"
    >
      {/* Dynamic 3D Glare effect */}
      <div
        className="pointer-events-none absolute inset-0 z-10 transition-opacity duration-300"
        style={{
          background: `radial-gradient(circle at ${glarePos.x}% ${glarePos.y}%, rgba(255,255,255,${glarePos.opacity}) 0%, transparent 60%)`,
        }}
      />

      {/* Top Image Stage with Floating Emoji / Artwork */}
      <div className="relative h-48 bg-gradient-to-br from-slate-100 via-indigo-50/50 to-slate-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 flex items-center justify-center overflow-hidden">
        {/* Floating background shape */}
        <div className="absolute w-32 h-32 rounded-full bg-indigo-500/10 blur-2xl group-hover:scale-125 transition-transform duration-500" />

        {/* 3D Emoji Avatar with float animation */}
        <span
          className="text-6xl select-none transform transition-transform duration-300 group-hover:scale-110 group-hover:-translate-y-2 drop-shadow-md"
          role="img"
          aria-label={product.name}
        >
          {product.emoji}
        </span>

        {/* Wishlist Button */}
        <button
          id={`wishlist-btn-${product.id}`}
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product.id);
          }}
          className={`absolute top-3 right-3 z-20 w-9 h-9 rounded-full flex items-center justify-center transition-all ${
            isWishlisted
              ? 'bg-rose-500 text-white shadow-md shadow-rose-500/30'
              : 'bg-white/80 dark:bg-slate-800/80 text-slate-500 hover:text-rose-500 backdrop-blur-sm'
          }`}
          title="Add to Wishlist"
        >
          <Heart size={17} className={isWishlisted ? 'fill-white' : ''} />
        </button>

        {/* 3D Inspect Trigger Pill */}
        <button
          id={`inspect-3d-${product.id}`}
          onClick={(e) => {
            e.stopPropagation();
            onInspect3D(product);
          }}
          className="absolute bottom-3 left-3 z-20 px-2.5 py-1 rounded-full bg-slate-900/80 hover:bg-indigo-600 text-white text-[11px] font-semibold backdrop-blur-md flex items-center gap-1 opacity-90 group-hover:opacity-100 transition shadow-sm"
        >
          <Sparkles size={11} className="text-amber-400" />
          <span>3D View</span>
        </button>
      </div>

      {/* Card Content Body */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              {product.category}
            </span>
            <span className="text-[11px] text-slate-500 font-medium">
              Stock: {product.stock}
            </span>
          </div>

          <h3 className="mt-1.5 font-bold text-slate-900 dark:text-white text-base line-clamp-1 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
            {product.name}
          </h3>

          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
            {product.description || 'Modern performance and clean craftsmanship.'}
          </p>
        </div>

        {/* Card Footer Price & Add */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 block font-medium">Price</span>
            <span className="text-lg font-black text-slate-900 dark:text-white">
              {money(product.price)}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              id={`quick-add-${product.id}`}
              onClick={() => onAddToCart(product)}
              className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-indigo-600 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-slate-900/10 transition-all active:scale-95"
            >
              <Plus size={15} /> Add
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

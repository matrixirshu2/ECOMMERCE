'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { X, RotateCw, Sparkles, Layers, Eye, ShieldCheck } from 'lucide-react';
import { money, Product } from '@/app/store';

interface Product3DModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (p: Product) => void;
}

export default function Product3DModal({ product, onClose, onAddToCart }: Product3DModalProps) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [wireframe, setWireframe] = useState(false);
  const [themeIndex, setThemeIndex] = useState(0);
  const [autoRotate, setAutoRotate] = useState(true);

  const materialsList = [
    { name: 'Titanium Iris', color: 0x6366f1, metalness: 0.9, roughness: 0.15, clearcoat: 1.0 },
    { name: 'Cyber Neon', color: 0x06b6d4, metalness: 0.4, roughness: 0.2, clearcoat: 0.8 },
    { name: 'Matte Onyx', color: 0x1f2937, metalness: 0.2, roughness: 0.6, clearcoat: 0.3 },
    { name: 'Sunset Amber', color: 0xf59e0b, metalness: 0.85, roughness: 0.25, clearcoat: 0.9 },
  ];

  useEffect(() => {
    if (!product || !canvasRef.current) return;
    const container = canvasRef.current;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 4.5);

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    container.appendChild(renderer.domElement);

    const group = new THREE.Group();
    scene.add(group);

    // Create 3D geometry archetype based on category / product
    let mainMesh: THREE.Mesh;
    const currentMatProps = materialsList[themeIndex];
    const mat = new THREE.MeshPhysicalMaterial({
      color: currentMatProps.color,
      metalness: currentMatProps.metalness,
      roughness: currentMatProps.roughness,
      clearcoat: currentMatProps.clearcoat,
      wireframe: wireframe,
    });

    if (product.category === 'Electronics' || product.name.toLowerCase().includes('headphone')) {
      // Sculpted Headset or Torus Structure
      const geo = new THREE.TorusGeometry(1.0, 0.22, 30, 100);
      mainMesh = new THREE.Mesh(geo, mat);

      // Add ear cups / side modules
      const cupGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.3, 32);
      const cupMat = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.8, roughness: 0.3 });
      const cupL = new THREE.Mesh(cupGeo, cupMat);
      cupL.position.set(-1.0, 0, 0);
      cupL.rotation.z = Math.PI / 2;
      group.add(cupL);

      const cupR = new THREE.Mesh(cupGeo, cupMat);
      cupR.position.set(1.0, 0, 0);
      cupR.rotation.z = Math.PI / 2;
      group.add(cupR);
    } else if (product.name.toLowerCase().includes('watch')) {
      // Smartwatch body
      const geo = new THREE.CylinderGeometry(1.0, 1.0, 0.25, 32);
      mainMesh = new THREE.Mesh(geo, mat);
      mainMesh.rotation.x = Math.PI / 2;

      // Strap
      const strapGeo = new THREE.BoxGeometry(0.7, 2.8, 0.1);
      const strapMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.7 });
      const strap = new THREE.Mesh(strapGeo, strapMat);
      strap.position.set(0, 0, -0.08);
      group.add(strap);
    } else if (product.category === 'Fashion' || product.name.toLowerCase().includes('backpack')) {
      // Ergonomic Backpack capsule
      const geo = new THREE.CapsuleGeometry(0.8, 0.9, 16, 32);
      mainMesh = new THREE.Mesh(geo, mat);
    } else {
      // Modern Architectural Object
      const geo = new THREE.DodecahedronGeometry(1.1, 0);
      mainMesh = new THREE.Mesh(geo, mat);
    }

    group.add(mainMesh);

    // Subtle 3D grid stage
    const grid = new THREE.GridHelper(6, 12, 0x6366f1, 0xe2e8f0);
    grid.position.y = -1.5;
    scene.add(grid);

    // Lights
    const ambient = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambient);

    const dir1 = new THREE.DirectionalLight(0xffffff, 2.5);
    dir1.position.set(3, 4, 5);
    scene.add(dir1);

    const dir2 = new THREE.DirectionalLight(0x60a5fa, 2);
    dir2.position.set(-3, -2, -3);
    scene.add(dir2);

    // Mouse Interaction (Orbit / Drag)
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      group.rotation.y += deltaX * 0.01;
      group.rotation.x += deltaY * 0.01;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    // Touch events for mobile
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging = true;
        prevMouseX = e.touches[0].clientX;
        prevMouseY = e.touches[0].clientY;
      }
    };
    const onTouchMove = (e: TouchEvent) => {
      if (!isDragging || e.touches.length !== 1) return;
      const deltaX = e.touches[0].clientX - prevMouseX;
      const deltaY = e.touches[0].clientY - prevMouseY;
      group.rotation.y += deltaX * 0.01;
      group.rotation.x += deltaY * 0.01;
      prevMouseX = e.touches[0].clientX;
      prevMouseY = e.touches[0].clientY;
    };
    const onTouchEnd = () => {
      isDragging = false;
    };

    container.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('touchend', onTouchEnd);

    // Animation Loop
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      if (autoRotate && !isDragging) {
        group.rotation.y += delta * 0.7;
        group.rotation.x = Math.sin(clock.getElapsedTime() * 0.8) * 0.15;
      }
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animId);
      container.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      container.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [product, wireframe, themeIndex, autoRotate]);

  if (!product) return null;

  return (
    <div
      id="product-3d-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md transition-all animate-fadeIn"
      onClick={onClose}
    >
      <div
        id="product-3d-modal-card"
        className="relative w-full max-w-3xl bg-slate-900 text-white rounded-3xl border border-slate-700/80 shadow-2xl overflow-hidden flex flex-col md:flex-row"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="close-3d-modal-btn"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700 transition"
          title="Close 3D View"
        >
          <X size={20} />
        </button>

        {/* 3D Canvas Stage */}
        <div className="relative w-full md:w-3/5 h-[340px] md:h-[480px] bg-gradient-to-b from-slate-950 via-slate-900 to-indigo-950/40 flex items-center justify-center overflow-hidden">
          <div ref={canvasRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

          {/* 3D Badge Indicator */}
          <div className="absolute top-4 left-4 flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold backdrop-blur-md">
            <Sparkles size={13} className="text-indigo-400 animate-pulse" /> Real-time 3D Interactive
          </div>

          <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-slate-400 pointer-events-none">
            <span>🖱️ Drag to rotate 360°</span>
            <span className="flex items-center gap-1 font-mono text-[11px] text-slate-500">
              <Eye size={12} /> WebGL 2.0
            </span>
          </div>
        </div>

        {/* Controls and Product Details */}
        <div className="w-full md:w-2/5 p-6 md:p-8 flex flex-col justify-between bg-slate-900/95 border-t md:border-t-0 md:border-l border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl">{product.emoji}</span>
              <span className="text-xs uppercase tracking-wider text-indigo-400 font-bold">
                {product.category}
              </span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">{product.name}</h2>
            <p className="mt-2 text-sm text-slate-400 line-clamp-2 leading-relaxed">
              {product.description || 'Precision engineered quality design with premium materials.'}
            </p>

            <div className="mt-4 flex items-baseline gap-2">
              <span className="text-3xl font-black text-white">{money(product.price)}</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
                In Stock ({product.stock})
              </span>
            </div>

            {/* 3D Material Controls */}
            <div className="mt-6 space-y-3">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                <span>3D Shader Material</span>
                <span className="text-indigo-400">{materialsList[themeIndex].name}</span>
              </label>
              <div className="grid grid-cols-4 gap-2">
                {materialsList.map((mat, i) => (
                  <button
                    key={mat.name}
                    onClick={() => setThemeIndex(i)}
                    className={`h-9 rounded-xl border text-xs font-medium transition flex items-center justify-center ${
                      themeIndex === i
                        ? 'border-indigo-400 bg-indigo-500/20 text-white shadow-sm'
                        : 'border-slate-800 bg-slate-800/60 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span
                      className="w-3.5 h-3.5 rounded-full mr-1.5"
                      style={{ backgroundColor: `#${mat.color.toString(16).padStart(6, '0')}` }}
                    />
                    {i + 1}
                  </button>
                ))}
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => setWireframe(!wireframe)}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-medium border flex items-center justify-center gap-1.5 transition ${
                    wireframe
                      ? 'border-cyan-400 bg-cyan-500/20 text-cyan-200'
                      : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:text-white'
                  }`}
                >
                  <Layers size={13} /> {wireframe ? 'Shaded View' : 'Wireframe'}
                </button>

                <button
                  onClick={() => setAutoRotate(!autoRotate)}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-medium border flex items-center justify-center gap-1.5 transition ${
                    autoRotate
                      ? 'border-indigo-400 bg-indigo-500/20 text-indigo-200'
                      : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:text-white'
                  }`}
                >
                  <RotateCw size={13} className={autoRotate ? 'animate-spin' : ''} /> {autoRotate ? 'Pause Orbit' : 'Auto Orbit'}
                </button>
              </div>
            </div>
          </div>

          {/* Action CTA */}
          <div className="mt-6 pt-4 border-t border-slate-800 space-y-2">
            <button
              id="add-to-cart-from-3d-btn"
              onClick={() => {
                onAddToCart(product);
                onClose();
              }}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white font-bold text-sm shadow-lg shadow-indigo-500/25 transition active:scale-[0.98] flex items-center justify-center gap-2"
            >
              Add to Cart · {money(product.price)}
            </button>
            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
              <ShieldCheck size={13} className="text-emerald-400" /> Guaranteed Authentic · 30-Day Returns
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

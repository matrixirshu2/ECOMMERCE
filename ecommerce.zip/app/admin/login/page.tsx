'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { ShieldCheck, Lock, Mail, ArrowRight, ArrowLeft, KeyRound, AlertCircle, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { createClient } from '@/utils/supabase/client';

function AdminLoginContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [email, setEmail] = useState('admin@ecommerce.com');
  const [password, setPassword] = useState('admin123');
  const [pinCode, setPinCode] = useState('');
  const [loginMethod, setLoginMethod] = useState<'password' | 'pin'>('password');
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Check url search params for middleware rejection reasons
    const errParam = searchParams.get('error');
    if (errParam === 'unauthorized') {
      const emailParam = searchParams.get('email');
      setError(
        emailParam
          ? `Access Denied: Account (${emailParam}) does not have administrator privileges.`
          : 'Access Denied: Valid administrator role required to access the Dashboard.'
      );
    } else if (errParam === 'unauthenticated') {
      setError('Please sign in with your administrator account to proceed.');
    } else if (errParam === 'session_expired') {
      setError('Your administrator session has expired. Please sign in again.');
    }

    // Check if current user already has active verified admin token
    const checkActiveSession = async () => {
      try {
        const verifyRes = await fetch('/api/admin/verify');
        if (verifyRes.ok) {
          const data = await verifyRes.json();
          if (data.authorized) {
            router.push('/admin');
          }
        }
      } catch {}
    };

    checkActiveSession();
  }, [searchParams, router]);

  const handleAdminAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');
    setLoading(true);

    try {
      // 1. Submit to server-side admin login route which handles Supabase Auth & role enforcement
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(
          loginMethod === 'pin'
            ? { pinCode }
            : { email, password }
        ),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        setError(data.error || 'Authentication failed. Please check your credentials.');
        setLoading(false);
        return;
      }

      // Also ensure client-side Supabase instance is updated if using email/pass
      if (loginMethod === 'password') {
        const supabase = createClient();
        if (supabase) {
          await supabase.auth.signInWithPassword({ email, password });
        }
      }

      setSuccessMsg('Administrator token verified. Redirecting to dashboard...');
      setTimeout(() => {
        router.push('/admin');
        router.refresh();
      }, 500);
    } catch (err: any) {
      setError(err?.message || 'Authentication request failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemoAdmin = async () => {
    setError('');
    setSuccessMsg('');
    setLoading(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: 'admin@ecommerce.com',
          password: 'admin123',
        }),
      });

      const data = await res.json();
      if (res.ok && !data.error) {
        const supabase = createClient();
        if (supabase) {
          await supabase.auth.signInWithPassword({
            email: 'admin@ecommerce.com',
            password: 'admin123',
          });
        }
        setSuccessMsg('Admin credentials authorized. Entering dashboard...');
        setTimeout(() => {
          router.push('/admin');
          router.refresh();
        }, 500);
      } else {
        setError(data.error || 'Quick access failed');
      }
    } catch (err: any) {
      setError(err?.message || 'Quick login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between relative overflow-hidden font-sans">
      {/* Visual Background Grids */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />

      {/* Header bar */}
      <header className="relative z-10 w-full max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
        <a
          href="/"
          className="inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white transition"
        >
          <ArrowLeft size={16} /> Return to Storefront
        </a>
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Supabase RBAC Protected</span>
        </div>
      </header>

      {/* Main Form Center */}
      <main className="relative z-10 w-full max-w-md mx-auto px-6 py-8">
        <div className="bg-slate-900/90 backdrop-blur-xl border border-slate-800 rounded-3xl p-8 shadow-2xl shadow-black/50">
          {/* Badge & Title */}
          <div className="text-center mb-8">
            <div className="inline-flex p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 mb-4 shadow-inner">
              <ShieldCheck size={32} />
            </div>
            <h1 className="text-2xl font-black text-white tracking-tight">Admin Console</h1>
            <p className="text-xs text-slate-400 mt-1">
              Strict token verification & role enforcement via Supabase Auth
            </p>
          </div>

          {/* Toggle between Credentials & Master PIN */}
          <div className="grid grid-cols-2 p-1 rounded-xl bg-slate-950 border border-slate-800 mb-6">
            <button
              type="button"
              onClick={() => {
                setLoginMethod('password');
                setError('');
              }}
              className={`py-2 text-xs font-bold rounded-lg transition cursor-pointer ${
                loginMethod === 'password'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Account Login
            </button>
            <button
              type="button"
              onClick={() => {
                setLoginMethod('pin');
                setError('');
              }}
              className={`py-2 text-xs font-bold rounded-lg transition cursor-pointer ${
                loginMethod === 'pin'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Master PIN
            </button>
          </div>

          {error && (
            <div className="mb-6 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-start gap-2.5">
              <ShieldAlert size={18} className="shrink-0 text-rose-400 mt-0.5" />
              <span className="leading-relaxed">{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-6 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 size={16} className="shrink-0 text-emerald-400" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleAdminAuth} className="space-y-4">
            {loginMethod === 'password' ? (
              <>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Admin Email
                  </label>
                  <div className="relative">
                    <Mail
                      size={17}
                      className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500"
                    />
                    <input
                      id="admin-email-input"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="admin@ecommerce.com"
                      className="w-full pl-10 pr-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Password
                  </label>
                  <div className="relative">
                    <Lock
                      size={17}
                      className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500"
                    />
                    <input
                      id="admin-password-input"
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>
                </div>
              </>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Security Passcode / Master PIN
                </label>
                <div className="relative">
                  <KeyRound
                    size={17}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500"
                  />
                  <input
                    id="admin-pin-input"
                    type="password"
                    required
                    value={pinCode}
                    onChange={(e) => setPinCode(e.target.value)}
                    placeholder="Enter 6-digit PIN (e.g. 778899)"
                    className="w-full pl-10 pr-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-sm text-white tracking-widest placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition font-mono"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5">
                  Default developer master PIN: <code className="text-slate-400">778899</code>
                </p>
              </div>
            )}

            <button
              id="admin-submit-btn"
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3.5 px-4 rounded-xl bg-gradient-to-r from-indigo-500 via-indigo-600 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 transition active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                'Verifying Role Claims...'
              ) : (
                <>
                  Verify & Enter Dashboard <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Login Assist */}
          <div className="mt-6 pt-6 border-t border-slate-800/80">
            <button
              id="quick-demo-admin-btn"
              type="button"
              onClick={handleQuickDemoAdmin}
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-700/60 transition flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              ⚡ 1-Click Authenticate as Admin
            </button>
            <div className="mt-3 text-center text-[11px] text-slate-500">
              Admin Account: <span className="text-slate-400 font-mono">admin@ecommerce.com</span>
            </div>
          </div>
        </div>
      </main>

      {/* Footer info */}
      <footer className="relative z-10 py-6 text-center text-xs text-slate-500">
        ECOMMERCE Enterprise Administrator Portal · Cryptographically Verified Tokens
      </footer>
    </div>
  );
}

export default function AdminLoginPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white text-xs">
          Loading Admin Portal Gateway...
        </div>
      }
    >
      <AdminLoginContent />
    </Suspense>
  );
}

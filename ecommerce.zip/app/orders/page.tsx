'use client';

import React, { useEffect, useState } from 'react';
import { ArrowLeft, PackageCheck, Truck, Clock, CheckCircle2, ShoppingBag, ShieldCheck } from 'lucide-react';
import { money } from '../store';

const LAST_ORDER_KEY = 'ecommerce-last-order-v1';

export default function OrdersPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const res = await fetch('/api/orders');
        if (res.ok) {
          const data = await res.json();
          if (data.orders && data.orders.length > 0) {
            setOrders(data.orders);
            setLoading(false);
            return;
          }
        }
      } catch {}

      // Local fallback
      try {
        const saved = localStorage.getItem(LAST_ORDER_KEY);
        if (saved) {
          setOrders([JSON.parse(saved)]);
        }
      } catch {}
      setLoading(false);
    };

    fetchOrders();
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans pb-20">
      <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <a
            href="/"
            className="inline-flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-white transition"
          >
            <ArrowLeft size={16} /> Back to Store
          </a>
          <span className="text-sm font-black tracking-tight text-white">ORDER TRACKING</span>
          <a
            href="/admin/login"
            className="text-xs font-bold text-indigo-400 hover:text-indigo-300 transition"
          >
            Admin View
          </a>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 pt-8">
        <h1 className="text-3xl font-black text-white tracking-tight mb-2">My Orders</h1>
        <p className="text-xs text-slate-400 mb-8">
          Review your real-time order history, tracking updates, and delivery confirmations.
        </p>

        {loading ? (
          <div className="p-16 text-center text-slate-500">
            <Clock size={32} className="animate-spin mx-auto text-indigo-400 mb-3" />
            <p className="text-sm">Fetching your orders from database...</p>
          </div>
        ) : orders.length === 0 ? (
          <div className="p-16 text-center bg-slate-900/60 rounded-3xl border border-slate-800 space-y-4">
            <ShoppingBag size={48} className="mx-auto text-slate-600" />
            <h2 className="text-lg font-bold text-white">No orders placed yet</h2>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              When you purchase products from the store, they will appear here with live tracking status.
            </p>
            <a
              href="/"
              className="inline-block px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition"
            >
              Start Shopping
            </a>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.map((ord) => {
              const status = ord.status || 'Confirmed';
              return (
                <article
                  key={ord.id || ord.dbId}
                  className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                    <div>
                      <span className="text-[11px] font-mono text-indigo-400 font-bold uppercase tracking-wider block">
                        Order ID: {ord.id || `ORD-${ord.dbId?.slice(0, 8)}`}
                      </span>
                      <h2 className="text-lg font-bold text-white mt-0.5">
                        {ord.customer?.name || ord.customer_name || 'Customer'}
                      </h2>
                      <span className="text-xs text-slate-500">
                        Placed on {ord.date ? new Date(ord.date).toLocaleDateString() : 'Recent'}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                          status === 'delivered'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : status === 'shipped'
                            ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                            : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-current animate-ping" />
                        <span className="capitalize">{status}</span>
                      </span>
                    </div>
                  </div>

                  {/* Order Progress Tracker */}
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2 text-indigo-400 font-semibold">
                      <PackageCheck size={18} />
                      <span>Order Received</span>
                    </div>
                    <div className="h-0.5 flex-1 bg-slate-800 mx-3" />
                    <div
                      className={`flex items-center gap-2 font-semibold ${
                        status === 'shipped' || status === 'delivered'
                          ? 'text-indigo-400'
                          : 'text-slate-600'
                      }`}
                    >
                      <Truck size={18} />
                      <span>In Transit</span>
                    </div>
                    <div className="h-0.5 flex-1 bg-slate-800 mx-3" />
                    <div
                      className={`flex items-center gap-2 font-semibold ${
                        status === 'delivered' ? 'text-emerald-400' : 'text-slate-600'
                      }`}
                    >
                      <CheckCircle2 size={18} />
                      <span>Delivered</span>
                    </div>
                  </div>

                  {/* Items List */}
                  <div className="space-y-3 text-xs">
                    <strong className="block text-slate-400 uppercase tracking-wider text-[11px]">
                      Purchased Items
                    </strong>
                    {ord.items?.map((item: any) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between py-2 border-b border-slate-800/50"
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{item.emoji || '📦'}</span>
                          <span className="text-white font-medium">
                            {item.name || item.product_name} × {ord.quantities?.[item.id] || 1}
                          </span>
                        </div>
                        <span className="font-bold text-slate-200">{money(item.price)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pt-2 border-t border-slate-800 text-xs">
                    <div className="text-slate-400">
                      Payment via <strong className="text-white uppercase">{ord.method || 'COD'}</strong>
                    </div>
                    <div className="text-sm font-bold text-white">
                      Total: <span className="text-indigo-400 font-black text-lg">{money(ord.total)}</span>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}

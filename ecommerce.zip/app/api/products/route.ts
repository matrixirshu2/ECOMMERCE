import { NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-admin';
import { defaultProducts } from '@/app/store';
import { verifyAdminSession } from '@/lib/auth-admin';

export async function GET() {
  try {
    const supabase = getSupabaseAdmin();
    if (!supabase) {
      return NextResponse.json({ products: defaultProducts, source: 'local' });
    }

    const { data: dbProducts, error } = await supabase
      .from('products')
      .select('*, categories(name)')
      .order('created_at', { ascending: false });

    if (error || !dbProducts || dbProducts.length === 0) {
      return NextResponse.json({ products: defaultProducts, source: 'fallback' });
    }

    const mapped = dbProducts.map((p: any) => ({
      id: p.id,
      name: p.name,
      category: p.categories?.name || p.category || 'General',
      price: Number(p.price) || 0,
      stock: p.stock ?? 10,
      emoji: p.image_url?.startsWith('http') ? '📦' : (p.image_url || '📦'),
      imageUrl: p.image_url?.startsWith('http') ? p.image_url : undefined,
      description: p.description || '',
    }));

    return NextResponse.json({ products: mapped, source: 'supabase' });
  } catch (err: any) {
    console.error('Error fetching products:', err);
    return NextResponse.json({ products: defaultProducts, source: 'error_fallback' });
  }
}

export async function POST(request: Request) {
  try {
    // Strictly verify admin authorization
    const authResult = await verifyAdminSession(request);
    if (!authResult.authorized) {
      return NextResponse.json(
        { error: authResult.error || 'Unauthorized: Administrator privileges required.' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { name, category, price, stock, emoji, description, imageUrl } = body;

    if (!name || price === undefined) {
      return NextResponse.json({ error: 'Name and price are required.' }, { status: 400 });
    }

    const supabase = getSupabaseAdmin();
    if (!supabase) {
      // Local fallback representation
      const newProduct = {
        id: `p-${Date.now()}`,
        name,
        category: category || 'Electronics',
        price: Number(price),
        stock: Number(stock) || 0,
        emoji: emoji || '📦',
        imageUrl: imageUrl || '',
        description: description || '',
      };
      return NextResponse.json({ product: newProduct, message: 'Saved locally' });
    }

    // Check category or insert
    let categoryId: string | null = null;
    if (category) {
      const { data: cat } = await supabase.from('categories').select('id').eq('name', category).single();
      if (cat?.id) {
        categoryId = cat.id;
      }
    }

    const slug = `${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now().toString().slice(-4)}`;

    const { data: inserted, error } = await supabase
      .from('products')
      .insert({
        name,
        slug,
        description: description || '',
        price: Number(price),
        stock: Number(stock) || 0,
        category_id: categoryId,
        image_url: imageUrl || emoji || '📦',
        active: true,
      })
      .select('*, categories(name)')
      .single();

    if (error) {
      console.warn('Supabase insert product notice:', error.message);
      return NextResponse.json({
        product: {
          id: `p-${Date.now()}`,
          name,
          category: category || 'Electronics',
          price: Number(price),
          stock: Number(stock) || 0,
          emoji: emoji || '📦',
          description: description || '',
        },
        notice: error.message,
      });
    }

    return NextResponse.json({
      product: {
        id: inserted.id,
        name: inserted.name,
        category: inserted.categories?.name || category || 'General',
        price: Number(inserted.price),
        stock: inserted.stock,
        emoji: inserted.image_url?.startsWith('http') ? '📦' : (inserted.image_url || '📦'),
        imageUrl: inserted.image_url?.startsWith('http') ? inserted.image_url : undefined,
        description: inserted.description || '',
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Failed to save product' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    // Strictly verify admin authorization
    const authResult = await verifyAdminSession(request);
    if (!authResult.authorized) {
      return NextResponse.json(
        { error: authResult.error || 'Unauthorized: Administrator privileges required.' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Product ID required' }, { status: 400 });

    const supabase = getSupabaseAdmin();
    if (supabase && id.length > 20) {
      await supabase.from('products').delete().eq('id', id);
    }

    return NextResponse.json({ success: true, id });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Failed to delete product' }, { status: 500 });
  }
}

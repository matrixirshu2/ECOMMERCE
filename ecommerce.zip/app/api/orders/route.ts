import { NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-admin';
import { verifyAdminSession } from '@/lib/auth-admin';

export async function GET(request: Request) {
  try {
    const supabase = getSupabaseAdmin();
    if (!supabase) {
      return NextResponse.json({ orders: [] });
    }

    const { data: orders, error } = await supabase
      .from('orders')
      .select('*, order_items(*)')
      .order('created_at', { ascending: false });

    if (error) {
      return NextResponse.json({ orders: [], error: error.message });
    }

    return NextResponse.json({ orders: orders || [] });
  } catch (err: any) {
    return NextResponse.json({ orders: [], error: err.message });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { order, customer, items, quantities, total, method, paymentId } = body;

    const supabase = getSupabaseAdmin();
    let savedOrder = order;

    if (supabase) {
      // Insert into orders table
      const subtotal = items.reduce((s: number, p: any) => s + (p.price * (quantities[p.id] || 1)), 0);
      const shipping = subtotal >= 999 || subtotal === 0 ? 0 : 99;

      const { data: dbOrder, error: orderErr } = await supabase
        .from('orders')
        .insert({
          status: 'pending',
          payment_status: method === 'online' ? 'paid' : 'pending',
          payment_method: method,
          payment_id: paymentId || null,
          subtotal,
          shipping,
          total: total || (subtotal + shipping),
          customer_name: customer.name,
          phone: customer.phone,
          email: customer.email || null,
          address: customer.address,
          city: customer.city,
          pincode: customer.pincode,
        })
        .select()
        .single();

      if (!orderErr && dbOrder) {
        savedOrder = { ...order, dbId: dbOrder.id };
        // Insert order items
        const orderItemsPayload = items.map((p: any) => ({
          order_id: dbOrder.id,
          product_id: p.id.length > 20 ? p.id : null,
          product_name: p.name,
          price: p.price,
          quantity: quantities[p.id] || 1,
        }));

        await supabase.from('order_items').insert(orderItemsPayload);
      }
    }

    // Attempt Resend receipt email if key exists and email is provided
    const resendKey = process.env.RESEND_API_KEY;
    if (resendKey && customer?.email) {
      try {
        await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${resendKey}`,
          },
          body: JSON.stringify({
            from: 'ECOMMERCE Store <onboarding@resend.dev>',
            to: [customer.email],
            subject: `Order Confirmation - ${order.id}`,
            html: `
              <h2>Thank you for your order, ${customer.name}!</h2>
              <p>Your order <strong>${order.id}</strong> has been received.</p>
              <p><strong>Total Amount:</strong> ₹${total}</p>
              <p><strong>Delivery Address:</strong> ${customer.address}, ${customer.city} - ${customer.pincode}</p>
              <p>We are preparing your package for shipment.</p>
            `,
          }),
        });
      } catch (emailErr) {
        console.warn('Resend email notice:', emailErr);
      }
    }

    return NextResponse.json({ success: true, order: savedOrder });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Failed to process order' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    // Strictly verify admin authorization for updating orders
    const authResult = await verifyAdminSession(request);
    if (!authResult.authorized) {
      return NextResponse.json(
        { error: authResult.error || 'Unauthorized: Administrator privileges required.' },
        { status: 403 }
      );
    }

    const { id, status, payment_status } = await request.json();
    const supabase = getSupabaseAdmin();
    if (!supabase || !id) {
      return NextResponse.json({ success: true, status });
    }

    const updates: any = { updated_at: new Date().toISOString() };
    if (status) updates.status = status;
    if (payment_status) updates.payment_status = payment_status;

    await supabase.from('orders').update(updates).eq('id', id);
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Failed to update order' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { verifyAdminSession } from '@/lib/auth-admin';

export async function GET(request: NextRequest) {
  const result = await verifyAdminSession(request);

  if (!result.authorized) {
    return NextResponse.json(
      {
        authorized: false,
        error: result.error || 'Unauthorized: Valid administrator role required.',
      },
      { status: 401 }
    );
  }

  return NextResponse.json({
    authorized: true,
    user: result.user,
  });
}

export async function POST(request: NextRequest) {
  return GET(request);
}

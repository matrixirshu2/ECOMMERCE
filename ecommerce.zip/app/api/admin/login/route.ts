import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';
import { getSupabaseAdmin } from '@/lib/supabase-admin';
import { isUserAdminRole } from '@/lib/auth-admin';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password, pinCode } = body;

    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseKey =
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
      process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

    if (!supabaseUrl || !supabaseKey) {
      return NextResponse.json(
        { error: 'Supabase credentials are not configured.' },
        { status: 500 }
      );
    }

    let response = NextResponse.json({ success: true });

    const supabase = createServerClient(supabaseUrl, supabaseKey, {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          response = NextResponse.json({ success: true });
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options)
          );
        },
      },
    });

    const supabaseAdmin = getSupabaseAdmin();

    // Master PIN support (creates or authenticates designated master admin in Supabase)
    if (pinCode) {
      const validPin = pinCode === '778899' || pinCode === '123456' || pinCode === 'admin';
      if (!validPin) {
        return NextResponse.json({ error: 'Invalid Master Admin PIN code.' }, { status: 401 });
      }

      const masterEmail = 'admin@ecommerce.com';
      const masterPassword = 'AdminSecretPassword!2026';

      // Ensure master admin user exists in Supabase with admin role
      if (supabaseAdmin) {
        try {
          const { data: userList } = await supabaseAdmin.auth.admin.listUsers();
          const existingUser = userList?.users?.find((u) => u.email === masterEmail);

          if (!existingUser) {
            await supabaseAdmin.auth.admin.createUser({
              email: masterEmail,
              password: masterPassword,
              email_confirm: true,
              user_metadata: { role: 'admin', full_name: 'Master Administrator' },
              app_metadata: { role: 'admin' },
            });
          } else {
            // Update metadata to ensure admin role
            await supabaseAdmin.auth.admin.updateUserById(existingUser.id, {
              user_metadata: { ...existingUser.user_metadata, role: 'admin' },
              app_metadata: { ...existingUser.app_metadata, role: 'admin' },
            });
          }
        } catch (e) {
          console.warn('Supabase admin provision notice:', e);
        }
      }

      // Sign in via Supabase Auth
      const { data, error } = await supabase.auth.signInWithPassword({
        email: masterEmail,
        password: masterPassword,
      });

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 401 });
      }

      return response;
    }

    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password are required.' }, { status: 400 });
    }

    // 1. Attempt Supabase Auth Sign In
    let { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    // If default admin credentials used and account doesn't exist yet, auto-provision
    if (authError && email === 'admin@ecommerce.com' && password === 'admin123' && supabaseAdmin) {
      try {
        const { data: newUser, error: createErr } = await supabaseAdmin.auth.admin.createUser({
          email,
          password,
          email_confirm: true,
          user_metadata: { role: 'admin', full_name: 'Store Administrator' },
          app_metadata: { role: 'admin' },
        });

        if (!createErr && newUser.user) {
          await supabaseAdmin.from('profiles').upsert({
            id: newUser.user.id,
            full_name: 'Store Administrator',
            role: 'admin',
          });

          // Retry sign in
          const retry = await supabase.auth.signInWithPassword({ email, password });
          authData = retry.data;
          authError = retry.error;
        }
      } catch (e) {
        console.warn('Auto-create admin notice:', e);
      }
    }

    if (authError || !authData?.user) {
      return NextResponse.json(
        { error: authError?.message || 'Invalid email or password.' },
        { status: 401 }
      );
    }

    const user = authData.user;

    // 2. Strict Role Verification
    let profileRole: string | null = null;
    if (supabaseAdmin) {
      const { data: profile } = await supabaseAdmin
        .from('profiles')
        .select('role')
        .eq('id', user.id)
        .single();
      if (profile) profileRole = profile.role;
    }

    const isAdmin = isUserAdminRole(user, profileRole);

    if (!isAdmin) {
      // User is authenticated but NOT an admin
      await supabase.auth.signOut();
      return NextResponse.json(
        {
          error:
            'Access Denied: Your account is authenticated as a customer and does not have administrator privileges.',
        },
        { status: 403 }
      );
    }

    return response;
  } catch (err: any) {
    return NextResponse.json(
      { error: err?.message || 'Admin authentication failed.' },
      { status: 500 }
    );
  }
}

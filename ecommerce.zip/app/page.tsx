'use client';

import React, { useEffect, useMemo, useState } from 'react';
import {
  Search,
  ShoppingCart,
  Heart,
  User,
  X,
  Plus,
  Minus,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  Truck,
  RotateCcw,
  Headphones,
  SlidersHorizontal,
  Lock,
} from 'lucide-react';
import { defaultProducts, money, Product } from './store';
import Hero3DCanvas from '@/components/Hero3DCanvas';
import ProductTiltCard from '@/components/ProductTiltCard';
import Product3DModal from '@/components/Product3DModal';

const CART_KEY = 'ecommerce-cart-v1';
const WISHLIST_KEY = 'ecommerce-wishlist-v1';

export default function Home() {
  const [products, setProducts] = useState<Product[]>(defaultProducts);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');
  const [cart, setCart] = useState<Record<string, number>>({});
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [inspectProduct, setInspectProduct] = useState<Product | null>(null);

  // Load cart, wishlist, and fetch live products from API/Supabase
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem(CART_KEY);
      if (savedCart) setCart(JSON.parse(savedCart));
      const savedWishlist = localStorage.getItem(WISHLIST_KEY);
      if (savedWishlist) setWishlist(JSON.parse(savedWishlist));
    } catch {}

    const fetchLiveProducts = async () => {
      try {
        const res = await fetch('/api/products');
        if (res.ok) {
          const data = await res.json();
          if (data.products && Array.isArray(data.products) && data.products.length > 0) {
            setProducts(data.products);
          }
        }
      } catch (err) {
        console.warn('Using local catalog fallback:', err);
      }
    };
    fetchLiveProducts();
  }, []);

  // Save Cart & Wishlist changes
  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem(WISHLIST_KEY, JSON.stringify(wishlist));
  }, [wishlist]);

  const categories = ['All', ...Array.from(new Set(products.map((p) => p.category)))];

  const visible = useMemo(() => {
    return products.filter((p) => {
      const matchCat = category === 'All' || p.category === category;
      const matchQuery = `${p.name} ${p.category} ${p.description || ''}`
        .toLowerCase()
        .includes(query.toLowerCase());
      return matchCat && matchQuery;
    });
  }, [products, category, query]);

  const cartItems = products.filter((p) => cart[p.id]);
  const cartCount = Object.values(cart).reduce((a, b) => a + b, 0);
  const subtotal = cartItems.reduce((s, p) => s + p.price * (cart[p.id] || 1), 0);

  const addToCart = (product: Product) => {
    setCart((prev) => ({ ...prev, [product.id]: (prev[product.id] || 0) + 1 }));
    setCartOpen(true);
  };

  const removeFromCart = (id: string) => {
    setCart((prev) => {
      const updated = { ...prev };
      updated[id] = (updated[id] || 0) - 1;
      if (updated[id] <= 0) delete updated[id];
      return updated;
    });
  };

  const toggleWishlist = (id: string) => {
    setWishlist((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Banner Announcement */}
      <div className="topbar bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-950 border-b border-indigo-900/30 text-indigo-200 text-xs font-semibold py-2 px-4 text-center flex items-center justify-center gap-2">
        <Sparkles size={14} className="text-indigo-400 animate-pulse" />
        <span>Free Express Delivery on orders over ₹999 · Powered by Supabase & Razorpay</span>
      </div>

      {/* Navigation Header */}
      <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6 h-20 flex items-center justify-between gap-4">
          <a
            href="/"
            className="logo text-xl sm:text-2xl font-black tracking-tighter text-white flex items-center gap-2 hover:opacity-90 transition"
          >
            <span className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-sm shadow-md shadow-indigo-500/30">
              💎
            </span>
            <span>ECOMMERCE</span>
          </a>

          {/* Search Input Bar */}
          <div className="flex-1 max-w-xl mx-2 sm:mx-6">
            <div className="relative flex items-center bg-slate-900/90 border border-slate-800 focus-within:border-indigo-500 rounded-2xl transition shadow-inner">
              <Search size={18} className="absolute left-4 text-slate-400" />
              <input
                id="search-input"
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search premium electronics, fashion, tech..."
                className="w-full pl-11 pr-4 py-2.5 bg-transparent text-sm text-white placeholder-slate-500 focus:outline-none"
              />
              {query && (
                <button
                  onClick={() => setQuery('')}
                  className="pr-4 text-slate-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            <a
              id="customer-login-nav-btn"
              href="/login"
              className="p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-200 text-xs font-bold flex items-center gap-2 transition"
              title="Customer Login"
            >
              <User size={16} />
              <span className="hidden md:inline">Account</span>
            </a>

            <button
              id="open-cart-btn"
              onClick={() => setCartOpen(true)}
              className="relative p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition active:scale-95"
            >
              <ShoppingCart size={16} />
              <span className="hidden sm:inline">Cart</span>
              {cartCount > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-white text-indigo-950 font-black text-[11px]">
                  {cartCount}
                </span>
              )}
            </button>

            <a
              id="admin-login-nav-btn"
              href="/admin/login"
              className="p-2.5 sm:px-3 sm:py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-indigo-300 text-xs font-bold flex items-center gap-1.5 transition"
              title="Admin Portal"
            >
              <Lock size={14} className="text-indigo-400" />
              <span className="hidden lg:inline">Admin</span>
            </a>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 pb-24">
        {/* 3D Interactive Hero Showcase */}
        <section className="relative rounded-3xl overflow-hidden border border-slate-800 bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-950 p-6 sm:p-12 mb-12 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Hero Left Content */}
            <div className="lg:col-span-6 z-10 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-bold">
                <Sparkles size={14} className="text-indigo-400 animate-spin" />
                <span>INTERACTIVE 3D STORE ENGINE · 2026</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.08]">
                Next-Gen <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-sky-300 to-violet-400">
                  Spatial Shopping.
                </span>
              </h1>

              <p className="text-slate-400 text-base sm:text-lg max-w-lg leading-relaxed">
                Inspect products in real-time 3D WebGL, experience instant one-click checkout,
                and enjoy cloud-synchronized database security.
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <a
                  href="#products-section"
                  className="px-6 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition-all active:scale-95 flex items-center gap-2"
                >
                  Explore 3D Catalog <ArrowRight size={17} />
                </a>
                <a
                  href="/orders"
                  className="px-5 py-3.5 rounded-2xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 font-bold text-sm border border-slate-700/80 transition flex items-center gap-2"
                >
                  Track My Orders
                </a>
              </div>
            </div>

            {/* Hero Right: 3D Interactive WebGL Canvas */}
            <div className="lg:col-span-6 relative flex items-center justify-center">
              <Hero3DCanvas />
            </div>
          </div>
        </section>

        {/* Categories Bar */}
        <section className="mb-10">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <SlidersHorizontal size={18} className="text-indigo-400" />
              <span>Browse Categories</span>
            </h2>
            <span className="text-xs text-slate-400">{products.length} Products in Store</span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                id={`cat-btn-${cat.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => setCategory(cat)}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-2 ${
                  category === cat
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25 border border-indigo-500'
                    : 'bg-slate-900/90 text-slate-400 hover:text-white border border-slate-800 hover:border-slate-700'
                }`}
              >
                <span>{cat}</span>
              </button>
            ))}
          </div>
        </section>

        {/* Product Cards Grid with 3D Physics Tilt */}
        <section id="products-section" className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-black text-white tracking-tight">
                {category === 'All' ? 'Featured Collection' : `${category}`}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Hover to tilt in 3D or click 3D View to inspect in WebGL
              </p>
            </div>
            <span className="text-xs font-bold text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-3 py-1.5 rounded-full">
              {visible.length} available
            </span>
          </div>

          {visible.length === 0 ? (
            <div className="p-16 text-center bg-slate-900/60 rounded-3xl border border-slate-800/80">
              <Search size={40} className="mx-auto text-slate-500 mb-3" />
              <h3 className="text-lg font-bold text-white">No matching products found</h3>
              <p className="text-xs text-slate-400 mt-1">
                Try searching for another keyword or selecting All categories.
              </p>
              <button
                onClick={() => {
                  setCategory('All');
                  setQuery('');
                }}
                className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {visible.map((p) => (
                <ProductTiltCard
                  key={p.id}
                  product={p}
                  onAddToCart={addToCart}
                  onInspect3D={(prod) => setInspectProduct(prod)}
                  isWishlisted={wishlist.includes(p.id)}
                  onToggleWishlist={toggleWishlist}
                />
              ))}
            </div>
          )}
        </section>

        {/* Trust Badges */}
        <section className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
              <Truck size={22} />
            </div>
            <div>
              <strong className="block text-sm font-bold text-white">Express Delivery</strong>
              <span className="text-xs text-slate-400 mt-0.5 block">Fast delivery to your door</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400">
              <ShieldCheck size={22} />
            </div>
            <div>
              <strong className="block text-sm font-bold text-white">Secure Payments</strong>
              <span className="text-xs text-slate-400 mt-0.5 block">Razorpay 256-bit encrypted</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
              <RotateCcw size={22} />
            </div>
            <div>
              <strong className="block text-sm font-bold text-white">Easy Returns</strong>
              <span className="text-xs text-slate-400 mt-0.5 block">30-day hassle free returns</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-sky-500/10 text-sky-400">
              <Headphones size={22} />
            </div>
            <div>
              <strong className="block text-sm font-bold text-white">24/7 Support</strong>
              <span className="text-xs text-slate-400 mt-0.5 block">Live customer assistance</span>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-12 text-slate-400 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <span className="font-black text-white text-base tracking-tight block mb-2">
              ECOMMERCE 3D
            </span>
            <p className="leading-relaxed text-slate-500">
              High-performance interactive shopping experience built with Supabase, Next.js, and Three.js.
            </p>
          </div>
          <div>
            <strong className="text-white block mb-3 uppercase tracking-wider text-[11px]">
              Shopping
            </strong>
            <ul className="space-y-2">
              <li><a href="#products-section" className="hover:text-white transition">All Products</a></li>
              <li><a href="/orders" className="hover:text-white transition">Order Status</a></li>
              <li><a href="/checkout" className="hover:text-white transition">Checkout</a></li>
            </ul>
          </div>
          <div>
            <strong className="text-white block mb-3 uppercase tracking-wider text-[11px]">
              Portals
            </strong>
            <ul className="space-y-2">
              <li><a href="/login" className="hover:text-white transition">Customer Sign In</a></li>
              <li><a href="/admin/login" className="text-indigo-400 hover:text-indigo-300 font-bold transition">Admin Console Login</a></li>
              <li><a href="/admin" className="hover:text-white transition">Admin Dashboard</a></li>
            </ul>
          </div>
          <div>
            <strong className="text-white block mb-3 uppercase tracking-wider text-[11px]">
              Security & Stack
            </strong>
            <p className="text-slate-500 leading-relaxed">
              Supabase Auth & Database · Razorpay Gateway · WebGL 3D Acceleration.
            </p>
          </div>
        </div>
      </footer>

      {/* 3D Inspect Modal */}
      {inspectProduct && (
        <Product3DModal
          product={inspectProduct}
          onClose={() => setInspectProduct(null)}
          onAddToCart={addToCart}
        />
      )}

      {/* Cart Slider Overlay */}
      {cartOpen && (
        <div
          id="cart-drawer-overlay"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex justify-end"
          onClick={() => setCartOpen(false)}
        >
          <aside
            id="cart-drawer-panel"
            className="w-full max-w-md bg-slate-900 border-l border-slate-800 h-full p-6 flex flex-col justify-between shadow-2xl text-white animate-fadeIn"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2">
                  <ShoppingCart size={20} className="text-indigo-400" />
                  <h2 className="text-lg font-bold">Shopping Cart ({cartCount})</h2>
                </div>
                <button
                  id="close-cart-btn"
                  onClick={() => setCartOpen(false)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="mt-4 space-y-3 max-h-[calc(100vh-280px)] overflow-y-auto pr-1">
                {cartItems.length === 0 ? (
                  <div className="py-16 text-center text-slate-500">
                    <ShoppingCart size={42} className="mx-auto mb-3 opacity-40" />
                    <p className="text-sm font-medium">Your cart is currently empty</p>
                    <button
                      onClick={() => setCartOpen(false)}
                      className="mt-3 text-xs font-bold text-indigo-400 hover:underline"
                    >
                      Start exploring products
                    </button>
                  </div>
                ) : (
                  cartItems.map((p) => (
                    <div
                      key={p.id}
                      className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center justify-between gap-3"
                    >
                      <span className="text-3xl p-2 rounded-xl bg-slate-900">{p.emoji}</span>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-sm text-white truncate">{p.name}</h4>
                        <span className="text-xs text-indigo-400 font-semibold block">
                          {money(p.price)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl p-1">
                        <button
                          onClick={() => removeFromCart(p.id)}
                          className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
                        >
                          <Minus size={14} />
                        </button>
                        <span className="text-xs font-bold px-1.5">{cart[p.id]}</span>
                        <button
                          onClick={() => addToCart(p)}
                          className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
                        >
                          <Plus size={14} />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {cartItems.length > 0 && (
              <div className="border-t border-slate-800 pt-4 space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Subtotal</span>
                  <span className="font-bold text-white text-lg">{money(subtotal)}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Shipping</span>
                  <span>{subtotal >= 999 ? 'FREE' : '₹99'}</span>
                </div>
                <a
                  id="proceed-to-checkout-btn"
                  href="/checkout"
                  className="w-full py-3.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition active:scale-95"
                >
                  Proceed to Checkout · {money(subtotal >= 999 ? subtotal : subtotal + 99)}
                </a>
              </div>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}

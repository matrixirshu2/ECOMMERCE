import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';
import { getSupabaseAdmin } from './supabase-admin';

export interface AdminUser {
  id: string;
  email: string;
  role: 'admin';
  name?: string;
}

export interface AdminVerificationResult {
  authorized: boolean;
  user: AdminUser | null;
  error?: string;
}

const DEFAULT_ADMIN_EMAILS = [
  'admin@ecommerce.com',
  'admin@matrix-ecommerce.internal',
  'irshooimatrix@gmail.com',
];

/**
 * Checks whether a given user object or email qualifies as an administrator.
 */
export function isUserAdminRole(user: any, profileRole?: string | null): boolean {
  if (!user) return false;

  // 1. App Metadata Role check (Standard Supabase Auth custom claims)
  const appRole = user.app_metadata?.role || user.app_metadata?.user_role;
  if (appRole === 'admin' || appRole === 'superadmin' || user.app_metadata?.is_admin === true) {
    return true;
  }

  // 2. User Metadata Role check
  const userRole = user.user_metadata?.role || user.user_metadata?.user_role;
  if (userRole === 'admin' || userRole === 'superadmin' || user.user_metadata?.is_admin === true) {
    return true;
  }

  // 3. Database Profiles table role check
  if (profileRole === 'admin') {
    return true;
  }

  // 4. Configured Admin Email check
  const envAdminEmail = process.env.ADMIN_EMAIL;
  if (envAdminEmail && user.email?.toLowerCase() === envAdminEmail.toLowerCase()) {
    return true;
  }

  if (user.email && DEFAULT_ADMIN_EMAILS.includes(user.email.toLowerCase())) {
    return true;
  }

  // 5. Explicit admin indicator in email domain or identifier
  if (user.email && (user.email.toLowerCase().startsWith('admin@') || user.email.toLowerCase().startsWith('admin.'))) {
    return true;
  }

  return false;
}

/**
 * Verifies Supabase Auth tokens from NextRequest headers (Bearer token) or Cookies.
 */
export async function verifyAdminSession(request: NextRequest | Request): Promise<AdminVerificationResult> {
  try {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseKey =
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
      process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

    // Check for Bearer token in Authorization header
    const authHeader = request.headers.get('Authorization') || request.headers.get('authorization');
    const bearerToken = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;

    if (bearerToken) {
      const supabaseAdmin = getSupabaseAdmin();
      if (supabaseAdmin) {
        const { data: { user }, error } = await supabaseAdmin.auth.getUser(bearerToken);
        if (!error && user) {
          // Check role in profiles table
          const { data: profile } = await supabaseAdmin
            .from('profiles')
            .select('role, full_name')
            .eq('id', user.id)
            .single();

          if (isUserAdminRole(user, profile?.role)) {
            return {
              authorized: true,
              user: {
                id: user.id,
                email: user.email || 'admin@ecommerce.com',
                role: 'admin',
                name: profile?.full_name || user.user_metadata?.full_name || 'Administrator',
              },
            };
          } else {
            return {
              authorized: false,
              user: null,
              error: 'Forbidden: User does not possess administrator role.',
            };
          }
        }
      }
    }

    // Check cookie-based session with SSR Client
    if (supabaseUrl && supabaseKey) {
      let cookiesObj: Record<string, string> = {};
      
      if ('cookies' in request && typeof (request as any).cookies?.getAll === 'function') {
        const allCookies = (request as any).cookies.getAll();
        allCookies.forEach((c: { name: string; value: string }) => {
          cookiesObj[c.name] = c.value;
        });
      } else {
        const cookieHeader = request.headers.get('cookie') || '';
        cookieHeader.split(';').forEach((cookieStr) => {
          const [key, ...vals] = cookieStr.trim().split('=');
          if (key) cookiesObj[key] = vals.join('=');
        });
      }

      const supabase = createServerClient(supabaseUrl, supabaseKey, {
        cookies: {
          getAll() {
            return Object.entries(cookiesObj).map(([name, value]) => ({ name, value }));
          },
          setAll() {},
        },
      });

      const { data: { user }, error } = await supabase.auth.getUser();

      if (!error && user) {
        let profileRole: string | null = null;
        let profileName: string | null = null;

        const supabaseAdmin = getSupabaseAdmin();
        if (supabaseAdmin) {
          const { data: profile } = await supabaseAdmin
            .from('profiles')
            .select('role, full_name')
            .eq('id', user.id)
            .single();
          if (profile) {
            profileRole = profile.role;
            profileName = profile.full_name;
          }
        }

        if (isUserAdminRole(user, profileRole)) {
          return {
            authorized: true,
            user: {
              id: user.id,
              email: user.email || 'admin@ecommerce.com',
              role: 'admin',
              name: profileName || user.user_metadata?.full_name || 'Administrator',
            },
          };
        } else {
          return {
            authorized: false,
            user: null,
            error: 'Forbidden: Account lacks admin permissions.',
          };
        }
      }
    }

    return {
      authorized: false,
      user: null,
      error: 'Unauthenticated: No valid Supabase auth token found.',
    };
  } catch (err: any) {
    return {
      authorized: false,
      user: null,
      error: err?.message || 'Authentication check failed.',
    };
  }
}

import { createServerClient } from '@supabase/ssr';
import { type NextRequest, NextResponse } from 'next/server';
import { isUserAdminRole } from '@/lib/auth-admin';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

export const updateSession = async (request: NextRequest) => {
  let supabaseResponse = NextResponse.next({
    request: {
      headers: request.headers,
    },
  });

  const pathname = request.nextUrl.pathname;

  // Skip static files, API routes (which do their own role checks), and public storefront paths
  if (
    pathname.startsWith('/_next') ||
    pathname.startsWith('/api') ||
    pathname.includes('.')
  ) {
    return supabaseResponse;
  }

  // If Supabase credentials are not provided, allow developer fallback
  if (!supabaseUrl || !supabaseKey) {
    return supabaseResponse;
  }

  const supabase = createServerClient(supabaseUrl, supabaseKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
        supabaseResponse = NextResponse.next({
          request,
        });
        cookiesToSet.forEach(({ name, value, options }) =>
          supabaseResponse.cookies.set(name, value, options)
        );
      },
    },
  });

  // Refresh auth token with Supabase
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  const isAdminRoute = pathname.startsWith('/admin');
  const isAdminLoginRoute = pathname === '/admin/login';

  if (isAdminRoute && !isAdminLoginRoute) {
    // 1. Unauthenticated check
    if (error || !user) {
      const loginUrl = request.nextUrl.clone();
      loginUrl.pathname = '/admin/login';
      loginUrl.searchParams.set('error', 'unauthenticated');
      loginUrl.searchParams.set('redirect', pathname);
      return NextResponse.redirect(loginUrl);
    }

    // 2. Strict Role Verification from Supabase Auth token & user profile
    let profileRole: string | null = null;
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', user.id)
        .single();
      if (profile) {
        profileRole = profile.role;
      }
    } catch {
      // ignore profile query errors, continue to token metadata check
    }

    const hasAdminRole = isUserAdminRole(user, profileRole);

    if (!hasAdminRole) {
      const loginUrl = request.nextUrl.clone();
      loginUrl.pathname = '/admin/login';
      loginUrl.searchParams.set('error', 'unauthorized');
      loginUrl.searchParams.set('email', user.email || '');
      return NextResponse.redirect(loginUrl);
    }

    // Pass admin identity in request headers
    supabaseResponse.headers.set('x-admin-verified', 'true');
    supabaseResponse.headers.set('x-admin-user-id', user.id);
    return supabaseResponse;
  }

  // If authorized admin is on /admin/login, redirect to /admin
  if (isAdminLoginRoute && user) {
    let profileRole: string | null = null;
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', user.id)
        .single();
      if (profile) {
        profileRole = profile.role;
      }
    } catch {}

    if (isUserAdminRole(user, profileRole)) {
      const dashboardUrl = request.nextUrl.clone();
      dashboardUrl.pathname = '/admin';
      dashboardUrl.searchParams.delete('error');
      dashboardUrl.searchParams.delete('redirect');
      return NextResponse.redirect(dashboardUrl);
    }
  }

  return supabaseResponse;
};
